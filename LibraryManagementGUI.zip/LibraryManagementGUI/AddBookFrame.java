import javax.swing.*;
import java.awt.*;
import java.sql.*;

class AddBookFrame extends JFrame {
    JTextField bname, bcode, total, subject;

    AddBookFrame() {
        setTitle("Add Book");
        setSize(300, 250);
        setLayout(new GridLayout(5, 2));

        add(new JLabel("Book Name:")); bname = new JTextField(); add(bname);
        add(new JLabel("Book Code:")); bcode = new JTextField(); add(bcode);
        add(new JLabel("Total:")); total = new JTextField(); add(total);
        add(new JLabel("Subject:")); subject = new JTextField(); add(subject);

        JButton save = new JButton("Save"); add(save);

        save.addActionListener(e -> {
            try {
                PreparedStatement pst = LibraryGUI.con.prepareStatement("INSERT INTO books VALUES (?, ?, ?, ?)");
                pst.setString(1, bname.getText());
                pst.setInt(2, Integer.parseInt(bcode.getText()));
                pst.setInt(3, Integer.parseInt(total.getText()));
                pst.setString(4, subject.getText());
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book added successfully.");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}

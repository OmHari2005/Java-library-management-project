import javax.swing.*;
import java.awt.*;
import java.sql.*;

class DeleteBookFrame extends JFrame {
    JTextField codeField;

    DeleteBookFrame() {
        setTitle("Delete Book");
        setSize(250, 150);
        setLayout(new FlowLayout());

        add(new JLabel("Enter Book Code:"));
        codeField = new JTextField(10); add(codeField);

        JButton deleteBtn = new JButton("Delete");
        add(deleteBtn);

        deleteBtn.addActionListener(e -> {
            try {
                PreparedStatement pst = LibraryGUI.con.prepareStatement("DELETE FROM books WHERE bcode = ?");
                pst.setInt(1, Integer.parseInt(codeField.getText()));
                int rows = pst.executeUpdate();
                if (rows > 0)
                    JOptionPane.showMessageDialog(this, "Book Deleted");
                else
                    JOptionPane.showMessageDialog(this, "Book Not Found");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LibraryGUI {
    static Connection con;

    public static void main(String[] args) {
        connectDatabase();
        new LoginFrame();
    }

    static void connectDatabase() {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "9634");
            Statement st = con.createStatement();
            st.executeUpdate("CREATE DATABASE IF NOT EXISTS LIBRARYMANAGEMENT");
            st.execute("USE LIBRARYMANAGEMENT");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS books(bname VARCHAR(20), bcode INT, total INT, subject VARCHAR(20))");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS issue(name VARCHAR(20), phoneno VARCHAR(20), regno INT, bcode INT, issue VARCHAR(20))");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS submit(name VARCHAR(20), phoneno VARCHAR(10), regno INT, bcode INT, submit DATE, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

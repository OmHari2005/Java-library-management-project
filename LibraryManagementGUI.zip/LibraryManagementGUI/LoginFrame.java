import javax.swing.*;
import java.awt.*;

class LoginFrame extends JFrame {
    JTextField passwordField;
    JButton loginButton;

    LoginFrame() {
        setTitle("Library Login");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel("Enter Password:"));
        passwordField = new JPasswordField(15);
        add(passwordField);

        loginButton = new JButton("Login");
        add(loginButton);

        loginButton.addActionListener(e -> {
            String pwd = passwordField.getText();
            if (pwd.equals("9634")) {
                dispose();
                new MainMenuFrame();
            } else {
                JOptionPane.showMessageDialog(this, "Wrong Password!");
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}

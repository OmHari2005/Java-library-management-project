import javax.swing.*;
import java.awt.*;

class MainMenuFrame extends JFrame {
    MainMenuFrame() {
        setTitle("Library Main Menu");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 1));

        JButton addBookBtn = new JButton("Add Book");
        JButton issueBookBtn = new JButton("Issue Book");
        JButton submitBookBtn = new JButton("Submit Book");
        JButton deleteBookBtn = new JButton("Delete Book");
        JButton viewBooksBtn = new JButton("View All Books");

        add(addBookBtn);
        add(issueBookBtn);
        add(submitBookBtn);
        add(deleteBookBtn);
        add(viewBooksBtn);

        addBookBtn.addActionListener(e -> new AddBookFrame());
        issueBookBtn.addActionListener(e -> new IssueBookFrame());
        submitBookBtn.addActionListener(e -> new SubmitBookFrame());
        deleteBookBtn.addActionListener(e -> new DeleteBookFrame());
        viewBooksBtn.addActionListener(e -> new ViewBooksFrame());

        setLocationRelativeTo(null);
        setVisible(true);
    }
}

import javax.swing.*;
import java.awt.*;
import java.sql.*;

class SubmitBookFrame extends JFrame {
    JTextField nameField, phoneField, regField, codeField, submitDateField;

    SubmitBookFrame() {
        setTitle("Submit Book");
        setSize(300, 300);
        setLayout(new GridLayout(6, 2));

        add(new JLabel("Student Name:")); nameField = new JTextField(); add(nameField);
        add(new JLabel("Phone Number:")); phoneField = new JTextField(); add(phoneField);
        add(new JLabel("Reg No:")); regField = new JTextField(); add(regField);
        add(new JLabel("Book Code:")); codeField = new JTextField(); add(codeField);
        add(new JLabel("Submit Date:")); submitDateField = new JTextField(); add(submitDateField);

        JButton submitBtn = new JButton("Submit"); add(submitBtn);

        submitBtn.addActionListener(e -> {
            try {
                PreparedStatement pst = LibraryGUI.con.prepareStatement(
                    "INSERT INTO submit (name, phoneno, regno, bcode, submit) VALUES (?, ?, ?, ?, ?)");
                pst.setString(1, nameField.getText());
                pst.setString(2, phoneField.getText());
                pst.setInt(3, Integer.parseInt(regField.getText()));
                pst.setInt(4, Integer.parseInt(codeField.getText()));
                pst.setString(5, submitDateField.getText());
                pst.executeUpdate();

                PreparedStatement update = LibraryGUI.con.prepareStatement("UPDATE books SET total = total + 1 WHERE bcode = ?");
                update.setInt(1, Integer.parseInt(codeField.getText()));
                update.executeUpdate();

                JOptionPane.showMessageDialog(this, "Book Submitted");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}

import javax.swing.*;
import java.awt.*;
import java.sql.*;

class ViewBooksFrame extends JFrame {
    ViewBooksFrame() {
        setTitle("All Books");
        setSize(400, 300);
        setLayout(new BorderLayout());

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        try {
            PreparedStatement pst = LibraryGUI.con.prepareStatement("SELECT * FROM books");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                textArea.append("Name: " + rs.getString("bname") + ", Code: " + rs.getInt("bcode") +
                        ", Total: " + rs.getInt("total") + ", Subject: " + rs.getString("subject") + "\n");
            }
        } catch (Exception ex) {
            textArea.setText("Error loading books.");
        }

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
